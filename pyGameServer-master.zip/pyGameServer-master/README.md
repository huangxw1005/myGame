# pyGameServer
a Simple Game Sever for Testing in Python including http server and socket server. It supports binary data and also protobuf.

##Setup
* Build and install [protobuf](https://github.com/google/protobuf) ref:[blog](http://blog.csdn.net/adamwu1988/article/details/56675221)
* create proto files and export to py files
* run gameserver
